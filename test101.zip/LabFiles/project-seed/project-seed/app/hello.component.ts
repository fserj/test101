import { Component } from '@angular/core';
@Component({
  selector: 'hello',
  template: '<h1>Hello Angular 2!</h1>'
})
export class HelloComponent { }
