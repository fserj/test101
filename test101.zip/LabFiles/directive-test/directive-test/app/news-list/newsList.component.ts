import { Component } from '@angular/core';

@Component({
    selector: "news-list",
    template: `
    <div>
        <div>
        <h3>Man Playing Pokémon Go App Eaten By Lions</h3>
        <p>
        Kenya, Africa - The instant addiction to the new Pokémon Go game has already reached all corners of the globe, causing its players all sorts of unique injuries in pursuit of hunting Pokémon.
        </p>
        <a href>More...</a>
        </div>

        <div>
        <h3>Amazon buys Rhode Island</h3>
        <p>
        In a move that will surely mark the beginning of the New World Order, Amazon has purchased the entire state of Rhode Island to be its western hemisphere distribution center.
        </p>
        <a href>More...</a>
        </div>

        <div>
        <h3>Telsa Motors Unveils Coal-Powered SUV</h3>
        <p>
        PALO ALTO, CA - Telsa Motors' CEO, Ellen Mush, announced their next "green" vehicle - The Telsa Model C. The model C is the first coal-powered vehicle since the 1884 Trepardeux. It was a coal fired steam propelled carriage.
        </p>
        <a href>More...</a>
        </div>

    </div>
    `
})
export class NewsList {

}