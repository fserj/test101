import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { NewsList } from './news-list/newsList.component';
import { NewsService } from './news-list/news.service';
import { HttpModule }    from '@angular/http';
import { ExpandHighlightDirective } from './common/expandHighlight.directive';
import { NewsSearchPipe } from './news-list/newsSearch.pipe';

@NgModule({
  imports:      [ BrowserModule, HttpModule, FormsModule ],
  declarations:  [ NewsList, ExpandHighlightDirective, NewsSearchPipe ],
  providers: [NewsService],
  bootstrap:     [ NewsList ]
})
export class AppModule { }
