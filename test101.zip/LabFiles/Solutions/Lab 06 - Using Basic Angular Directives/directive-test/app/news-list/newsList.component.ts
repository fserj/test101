import { Component } from '@angular/core';

@Component({
    selector: "news-list",
	styles: [`
    .collapsed {
        height: 16pt;
        overflow: hidden;
    }
    `],
    template: `
    <div>
        <div>
        <h3>Man Playing Pokémon Go App Eaten By Lions</h3>
        <p [ngClass]="{collapsed: selectedNewsId != 0}">
        Kenya, Africa - The instant addiction to the new Pokémon Go game has already reached all corners of the globe, causing its players all sorts of unique injuries in pursuit of hunting Pokémon.
        </p>
        <a href (click)="expandNews(0)" [hidden]="selectedNewsId == 0">More...</a>
        </div>

        <div>
        <h3>Amazon buys Rhode Island</h3>
        <p [ngClass]="{collapsed: selectedNewsId != 1}">
        In a move that will surely mark the beginning of the New World Order, Amazon has purchased the entire state of Rhode Island to be its western hemisphere distribution center.
        </p>
        <a href (click)="expandNews(1)" [hidden]="selectedNewsId == 1">More...</a>
        </div>

        <div>
        <h3>Telsa Motors Unveils Coal-Powered SUV</h3>
        <p [ngClass]="{collapsed: selectedNewsId != 2}">
        PALO ALTO, CA - Telsa Motors' CEO, Ellen Mush, announced their next "green" vehicle - The Telsa Model C. The model C is the first coal-powered vehicle since the 1884 Trepardeux. It was a coal fired steam propelled carriage.
        </p>
        <a href (click)="expandNews(2)" [hidden]="selectedNewsId == 2">More...</a>
        </div>

    </div>
    `
})
export class NewsList {
    selectedNewsId:number

    expandNews(id:number) {
        this.selectedNewsId = id

        return false
    }
}