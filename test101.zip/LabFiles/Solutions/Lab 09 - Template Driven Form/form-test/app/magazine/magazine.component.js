"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var Magazine = (function () {
    function Magazine() {
        this.fullName = "";
        this.editions = [
            { editionCode: 1, editionName: "US", price: "10.99 USD" },
            { editionCode: 2, editionName: "Canada", price: "14.99 CAD" },
            { editionCode: 3, editionName: "International", price: "23.99 USD" }
        ];
        this.selectedEdition = this.editions[0]; //Choose US by default
        this.selectedShipping = "";
        this.acceptPolicy = false;
    }
    Magazine.prototype.submitForm = function () {
        var requestData = {
            customerName: this.fullName,
            productCode: this.selectedEdition.editionCode,
            acceptPolicy: this.acceptPolicy,
            shipMode: this.selectedShipping
        };
        alert(JSON.stringify(requestData));
    };
    Magazine = __decorate([
        core_1.Component({
            selector: "magazine",
            template: "\n <form>\t\t\n    Full name:<br/>\n    <input name=\"fullName\" type=\"text\" [(ngModel)]=\"fullName\"/><br/>\n    Magazine edition:<br/>\n    <select name=\"selectedEdition\" [(ngModel)]=\"selectedEdition\">\n        <option *ngFor=\"let e of editions\" \n            [ngValue]=\"e\">{{e.editionName}}</option>\n    </select><br/>\n\tShipping option: \n    <input type=\"radio\" name=\"selectedShipping\"\n        [(ngModel)]=\"selectedShipping\" value=\"GROUND\"/>Ground \n    <input type=\"radio\" name=\"selectedShipping\"\n        [(ngModel)]=\"selectedShipping\" value=\"AIR\"/>Air <br/>\n\t<input name=\"acceptPolicy\" type=\"checkbox\" [(ngModel)]=\"acceptPolicy\"/>\n        I accept the terms and conditions<br/>\n\t\t<br/>\n    Price: {{selectedEdition.price}}\n    <br/>\n\t<button (click)=\"submitForm()\">Purchase</button>\n </form>\n    "
        }), 
        __metadata('design:paramtypes', [])
    ], Magazine);
    return Magazine;
}());
exports.Magazine = Magazine;
//# sourceMappingURL=magazine.component.js.map