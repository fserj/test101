import { Component } from '@angular/core';

@Component({
    selector: "magazine",
	    template: `
 <form>		
    Full name:<br/>
    <input name="fullName" type="text" [(ngModel)]="fullName"/><br/>
    Magazine edition:<br/>
    <select name="selectedEdition" [(ngModel)]="selectedEdition">
        <option *ngFor="let e of editions" 
            [ngValue]="e">{{e.editionName}}</option>
    </select><br/>
	Shipping option: 
    <input type="radio" name="selectedShipping"
        [(ngModel)]="selectedShipping" value="GROUND"/>Ground 
    <input type="radio" name="selectedShipping"
        [(ngModel)]="selectedShipping" value="AIR"/>Air <br/>
	<input name="acceptPolicy" type="checkbox" [(ngModel)]="acceptPolicy"/>
        I accept the terms and conditions<br/>
		<br/>
    Price: {{selectedEdition.price}}
    <br/>
	<button (click)="submitForm()">Purchase</button>
 </form>
    `
})

export class Magazine {
	submitForm() {
       let requestData = {
           customerName: this.fullName,
           productCode: this.selectedEdition.editionCode,
           acceptPolicy: this.acceptPolicy,
		   shipMode: this.selectedShipping
       }
       alert(JSON.stringify(requestData))
   }
   
  fullName = ""
  editions = [
    {editionCode: 1, editionName: "US", price: "10.99 USD"},
    {editionCode: 2, editionName: "Canada", price: "14.99 CAD"},
    {editionCode: 3, editionName: "International", price: "23.99 USD"}
  ]
  selectedEdition = this.editions[0] //Choose US by default
  selectedShipping = ""
  acceptPolicy = false
}