import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FancyCheckbox } from './FancyCheckbox/FancyCheckbox.component';
import { SubscriptionForm } from 
  './subscriptionForm/subscriptionForm.component';
import { FancyText } from './fancyText/fancyText.component';

@NgModule({
  imports:      [ BrowserModule ],
 declarations:  [ SubscriptionForm, FancyText, FancyCheckbox ],
  bootstrap:     [ SubscriptionForm ]
})
export class AppModule { }
