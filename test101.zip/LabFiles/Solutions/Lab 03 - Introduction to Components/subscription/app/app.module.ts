import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FancyCheckbox } from './FancyCheckbox/FancyCheckbox.component';

@NgModule({
  imports:      [ BrowserModule ],
  declarations:  [ FancyCheckbox ],
  bootstrap:     [ FancyCheckbox ]
})
export class AppModule { }
