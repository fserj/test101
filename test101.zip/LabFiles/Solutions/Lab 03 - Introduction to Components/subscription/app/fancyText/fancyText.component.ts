import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: "fancy-text",
  styleUrls: ["fancyText.component.css"],
  template: "<input type='text'/>"
})
export class FancyText { 
}

