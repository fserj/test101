"use strict";
var router_1 = require('@angular/router');
var all_component_1 = require('./all.component');
exports.routes = [
    { path: '', component: all_component_1.Home },
    { path: 'news', component: all_component_1.News },
    { path: 'about', component: all_component_1.About }
];
exports.routing = router_1.RouterModule.forRoot(exports.routes);
//# sourceMappingURL=app.routing.js.map